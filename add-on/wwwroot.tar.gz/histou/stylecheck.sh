phpcbf --standard=conf/phpcs.xml --no-patch .
phpcs --standard=conf/phpcs.xml .
phpunit -c conf/phpunit.xml