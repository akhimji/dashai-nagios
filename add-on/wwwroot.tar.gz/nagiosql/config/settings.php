<?php
exit;
?>
;///////////////////////////////////////////////////////////////////////////////
;
; NagiosQL
;
;///////////////////////////////////////////////////////////////////////////////
;
; Project  : NagiosQL
; Component: Database Configuration
; Website  : http://www.nagiosql.org
; Date     : April 25, 2017, 2:45 pm
; Version  : 3.2.0
;
;///////////////////////////////////////////////////////////////////////////////
[db]
server       = dashai-mariadb
port         = 3306
database     = db_nagiosql_v32
username     = root
password     = xpZtcC7AxD
[path]
base_url     = /nagiosql/
base_path    = /var/www/html/nagiosql/
